﻿namespace Manav_Otomasyonu
{


    partial class DataSet1
    {
    }
}
