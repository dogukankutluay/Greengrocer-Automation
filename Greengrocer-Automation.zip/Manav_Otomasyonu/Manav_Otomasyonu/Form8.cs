﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manav_Otomasyonu
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        public void Sepet()
        {
            //string connectionString = "Data Source=.;Initial Catalog=Hal;Integrated Security=True";
            //string sql = "SELECT *FROM Satış";
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlDataAdapter dataadapter = new SqlDataAdapter(sql, connection);
            //DataSet ds = new DataSet();
            //connection.Open();
            //dataadapter.Fill(ds, "Satış");            
            //dataGridView1.DataSource = ds;
            //dataGridView1.DataMember = "Satış";
            //connection.Close();
            SqlConnection con;
            SqlDataAdapter da;
            DataSet ds;
            con = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            da = new SqlDataAdapter("Select *From Satış", con);
            ds = new DataSet();
            con.Open();
            da.Fill(ds, "Ürün");           
            dataGridView1.DataSource = ds.Tables["Ürün"];            
            con.Close();
        }
        private void Form8_Load(object sender, EventArgs e)
        {
            Sepet();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti2 = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            SqlCommand cmd2 = new SqlCommand("DELETE FROM Satış", baglanti2);
            SqlCommand cmd3 = new SqlCommand("TRUNCATE TABLE Satış", baglanti2); //silinen tablo id sıfırlamak için
            baglanti2.Open();
            cmd3.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            baglanti2.Close();
            Sepet();
            
        }
    }
}
