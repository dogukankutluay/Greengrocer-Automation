﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manav_Otomasyonu
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            Armut();
        }
        public void Armut()
        {
            string connectionString = "Data Source=.;Initial Catalog=Hal;Integrated Security=True";
            string sql = "SELECT * FROM ArmutT";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter dataadapter = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            connection.Open();
            dataadapter.Fill(ds, "ArmutT");
            connection.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "ArmutT";
        }
        public int toplam = 0;//toplam ekleme
        private void button1_Click(object sender, EventArgs e)//anamenügeçiş
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            Armut();
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                int data = Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
                toplam += data;
                textBox1.Text = toplam.ToString();
            }
            using (SqlConnection connection = new SqlConnection("Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI"))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "SELECT Kilogram FROM ArmutT";
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader.GetValue(0));
                    }
                }
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string sql = "Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(sql);
            SqlCommand cmd = new SqlCommand();
            string selectedcmbox = comboBox1.SelectedItem.ToString();
            int intselect = Convert.ToInt32(comboBox1.SelectedItem);
            int kalan = toplam - intselect;

            if (selectedcmbox.ToString() == selectedcmbox.ToString())
            {
                cmd.Connection = con;
                cmd.CommandText = "delete from ArmutT where Kilogram=" + intselect + "";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                textBox1.Text = kalan.ToString();
                Armut();
                MessageBox.Show("SATIN ALINDI");
                Form5 form5 = new Form5();
                form5.Show();
                this.Hide();
            }
            if (selectedcmbox.ToString() == selectedcmbox.ToString())
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO Satış(Ürün,Kilgoram,Satılan_Kg,Kalan_Kg,Zaman) VALUES('" + "Armut" + "','" + toplam + "','" + intselect + "','" + kalan + "','" + DateTime.Now.ToString("t") + "')";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Armut();
                
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
            this.Hide();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            Form6 form6 = new Form6();
            form6.Show();
            this.Hide();
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection baglanti2 = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            SqlCommand cmd2 = new SqlCommand("DELETE FROM ArmutT", baglanti2);
            SqlCommand cmd3 = new SqlCommand("TRUNCATE TABLE ArmutT", baglanti2); //silinen tablo id sıfırlamak için
            baglanti2.Open();
            cmd3.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            baglanti2.Close();
            Armut();
        }
    }
}
