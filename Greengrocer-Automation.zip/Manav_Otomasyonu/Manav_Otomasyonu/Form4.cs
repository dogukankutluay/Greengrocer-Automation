﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manav_Otomasyonu
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Elma();
            
            
        }
        public void Elma()//dataya ekleme (elma)
        {
            string connectionString = "Data Source=.;Initial Catalog=Hal;Integrated Security=True";
            string sql = "SELECT * FROM ElmaT";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlDataAdapter dataadapter = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            //DataTable dt = new DataTable();
            connection.Open();

            
            dataadapter.Fill(ds, "ElmaT");
            connection.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "ElmaT";
            //comboBox1.DataSource = dt;
            //dataadapter.Fill(dt);
            //comboBox1.DisplayMember = "Kilogram";
            //comboBox1.ValueMember = "ID";



        }
        public  int toplam = 0;//toplam ekleme    
        private void Form4_Load(object sender, EventArgs e)// elma kg toplam belirleme
        {
            Elma();
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                int data = Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value);
                toplam += data;
                textBox1.Text = toplam.ToString();
            }
            using (SqlConnection connection = new SqlConnection("Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI"))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "SELECT Kilogram FROM ElmaT";
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBox1.Items.Add(reader.GetValue(0));
                    }
                }
            }


        }
        private void button1_Click(object sender, EventArgs e)//form 3 anamenü geçiş
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)//stoka satın alınanlara ekleme
        {
            #region deneme
            //int ekle = Convert.ToInt32(textBox2.Text);
            //int toplam1 = toplam - ekle;
            //if (ekle > toplam1)
            //{
            //    MessageBox.Show("Stoktaki ürün adetine göre giriniz");

            //}
            //else
            //{

            //    string sql = "Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI";
            //    SqlConnection con = new SqlConnection(sql);
            //    SqlCommand cmd = new SqlCommand();
            //    int kalan = ekle;
            //    textBox2.Text = kalan.ToString();
            //    cmd.Connection = con;
            //    cmd.CommandText = "INSERT INTO Satış(Ürün,Kilgoram,Satılan_Kg,Kalan_Kg,Zaman) VALUES('" + "Elma" + "','" + toplam + "','" + ekle + "','" + kalan + "','" + DateTime.Now.ToString("t") + "')";
            //    con.Open();
            //    cmd.ExecuteNonQuery();
            //    con.Close();
            //    textBox1.Text = toplam1.ToString();
            //    Elma();
            //    MessageBox.Show("SATIN ALINDI");
            //}
            #endregion
           

            string sql = "Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(sql);
            SqlCommand cmd = new SqlCommand();
            string selectedcmbox = comboBox1.SelectedItem.ToString();
            int intselect = Convert.ToInt32(comboBox1.SelectedItem);
            int kalan = toplam - intselect;
            
            if (selectedcmbox.ToString() == selectedcmbox.ToString())
            {
                cmd.Connection = con;               
                cmd.CommandText = "delete from ElmaT where Kilogram=" + intselect + "";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                textBox1.Text = kalan.ToString();
                Elma();
                MessageBox.Show("SATIN ALINDI");
                Form4 form4 = new Form4();
                form4.Show();
                this.Hide();
            }
            if (selectedcmbox.ToString() == selectedcmbox.ToString())
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO Satış(Ürün,Kilgoram,Satılan_Kg,Kalan_Kg,Zaman) VALUES('" + "Elma" + "','" + toplam + "','" + intselect + "','" + kalan + "','" + DateTime.Now.ToString("t") + "')";              
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                Elma();
            }
           
        }       
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        private void button5_Click(object sender, EventArgs e)//armut
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
        }   
        private void button6_Click_1(object sender, EventArgs e)//salata
        {
            Form6 form6 = new Form6();
            form6.Show();
            this.Hide();
        }
        private void button7_Click_1(object sender, EventArgs e)//patlıcan
        {
            Form7 form7 = new Form7();
            form7.Show();
            this.Hide();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void button3_Click(object sender, EventArgs e)// DAtAGRİDVİEWROW CLEAR
        {
            SqlConnection baglanti2 = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            SqlCommand cmd2 = new SqlCommand("DELETE FROM ElmaT", baglanti2);
            SqlCommand cmd3 = new SqlCommand("TRUNCATE TABLE ElmaT", baglanti2); //silinen tablo id sıfırlamak için
            baglanti2.Open();
            cmd3.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();
            baglanti2.Close();
            Elma();
        }
    }
}
