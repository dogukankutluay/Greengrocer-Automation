﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Data.OleDb;

namespace Manav_Otomasyonu
{
    public partial class Form2 : Form
    {   
        public Form2()
        {
            InitializeComponent();
        }       
        private void button1_Click(object sender, EventArgs e) // form1 geçiş
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)// form3 geçiş
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        private void Form2_Load(object sender, EventArgs e)// form2 load
        {          
            #region calısma
            //SqlConnection baglanti = new SqlConnection();
            //baglanti.ConnectionString = "Data Source=.;Initial Catalog=Hal;Integrated Security=SSPI";
            //SqlCommand komut = new SqlCommand();
            //komut.CommandText = "SELECT Columns FROM deneme";
            //komut.Connection = baglanti;
            //komut.CommandType = CommandType.Text;

            //SqlDataReader dr= komut.ExecuteReader();
            //baglanti.Open();
            //dr = komut.ExecuteReader();
            //while (dr.Read())
            //{
            //    comboBox1.Items.Add(dr["Name"]);
            //}
            //baglanti.Close();
            //SqlConnection con = new SqlConnection("Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI");
            //SqlCommand cmd = new SqlCommand();
            //cmd.Connection = con;
            //cmd.CommandText = "SELECT Column Name FROM deneme";
            //con.Open();

            //SqlDataReader dr = cmd.ExecuteReader();

            //ArrayList Isimler = new ArrayList();

            //while (dr.Read())
            //{
            //    Isimler.Add(dr["Name"]);
            //}

            //dr.Close();
            //con.Close();
            #endregion
            #region data veri cekme
            //List<string> listacolumnas = new List<string>();
            using (SqlConnection connection = new SqlConnection("Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI"))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "select c.name from sys.columns c inner join sys.tables t on t.object_id = c.object_id and t.name = 'Meyve' and t.type = 'U'";
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        
                        comboBox1.Items.Add(reader.GetString(0));
                    }
                }
            }
            using (SqlConnection connection = new SqlConnection("Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI"))
            using (SqlCommand command = connection.CreateCommand())
            {
                command.CommandText = "select c.name from sys.columns c inner join sys.tables t on t.object_id = c.object_id and t.name = 'Sebze' and t.type = 'U'";
                connection.Open();
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader.GetString(0));
                    }
                }
            }

            #endregion            
            toplam(); 
            
        }
        private void button3_Click(object sender, EventArgs e)// meyve ınsert
        {
            if (textBox1.Text != "")
            {
                string sql = "Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI";
                SqlConnection con = new SqlConnection(sql);
                SqlCommand cmd = new SqlCommand();
                string selectedcmbox = comboBox1.SelectedItem.ToString();
                if (selectedcmbox.ToString() == "Elma")
                {    
                    cmd.Connection = con;                   
                    cmd.CommandText= "INSERT INTO HalToplam(Çeşit,Kg) VALUES('" + selectedcmbox + "','" + textBox1.Text + "')";
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    toplam();                 
                    MessageBox.Show($"{textBox1.Text} Kilogram {selectedcmbox} siparişe eklendi");                  
                }
                if (selectedcmbox.ToString() == "Elma")
                {
                    cmd.Connection = con;
                    cmd.CommandText = "INSERT INTO ElmaT(Elma,Kilogram) VALUES('" + selectedcmbox + "','" + textBox1.Text + "')";
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();                                       
                }
                if (selectedcmbox.ToString() == "Armut")
                {
                    cmd.Connection = con;
                    cmd.CommandText = "INSERT INTO HalToplam(Çeşit,Kg) VALUES('" + selectedcmbox + "','" + textBox1.Text + "')";
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    toplam();
                    MessageBox.Show($"{textBox1.Text} Kilogram {selectedcmbox} siparişe eklendi");
                }
                if (selectedcmbox.ToString() == "Armut")
                {
                    cmd.Connection = con;
                    cmd.CommandText = "INSERT INTO ArmutT(Armut,Kilogram) VALUES('" + selectedcmbox + "','" + textBox1.Text + "')";
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        private void button5_Click(object sender, EventArgs e)//sebze ınsert
        {
            string sql = "Data Source =.; Initial Catalog = Hal; Integrated Security = SSPI";
            SqlConnection con = new SqlConnection(sql);
            SqlCommand cmd = new SqlCommand();
            string selectedcmbox = comboBox2.SelectedItem.ToString();
            if (selectedcmbox.ToString() == "Salata")// hale ekleme
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO HalToplam(Çeşit,Kg) VALUES('" + selectedcmbox + "','" + textBox2.Text + "')";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                toplam();
                MessageBox.Show($"{textBox2.Text} Kilogram {selectedcmbox} siparişe eklendi");
            }
            if (selectedcmbox.ToString() == "Salata")
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO SalataT(Salata,Kilogram) VALUES('" + selectedcmbox + "','" + textBox2.Text + "')";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();                
            }
            if (selectedcmbox.ToString() == "Patlıcan")// hale ekleme
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO HalToplam(Çeşit,Kg) VALUES('" + selectedcmbox + "','" + textBox2.Text + "')";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                toplam();
                MessageBox.Show($"{textBox2.Text} Kilogram {selectedcmbox} siparişe eklendi");

            }
            if (selectedcmbox.ToString() == "Patlıcan")
            {
                cmd.Connection = con;
                cmd.CommandText = "INSERT INTO PatlıcanT(Patlıcan,Kilogram) VALUES('" + selectedcmbox + "','" + textBox2.Text + "')";
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();                
            }
        }
        #region callısma
        //void elma()// Meyve datagriedview ınsert 
        //{
        //    SqlConnection con;
        //    SqlDataAdapter da;
        //    SqlDataAdapter de;
        //    DataSet ds;
        //    con = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
        //    da = new SqlDataAdapter("Select *From mKG", con);
        //    de = new SqlDataAdapter("Select *From HalToplam", con);
        //    ds = new DataSet();
        //    con.Open();
        //    de.Fill(ds, "Çeşit");
        //    da.Fill(ds, "Meyve");
        //    dataGridView3.DataSource = ds.Tables["Çeşit"];
        //    dataGridView1.DataSource = ds.Tables["Meyve"];
        //    con.Close();


        //}
        //void armut()// Sebze datagriedview ınsert
        //{
        //    SqlConnection con;
        //    SqlDataAdapter da;

        //    DataSet ds;
        //    con = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
        //    da = new SqlDataAdapter("Select *From sKG", con);
        //    ds = new DataSet();
        //    con.Open();
        //    da.Fill(ds, "Kilogram");
        //    da.Fill(ds, "Sebze");
        //    dataGridView2.DataSource = ds.Tables["Kilogram"];
        //    dataGridView2.DataSource = ds.Tables["Sebze"];
        //    con.Close();
        //}  
        #endregion
        void toplam()//Hal Sepeti ekleme
        {
            SqlConnection con;
            SqlDataAdapter da;
            DataSet ds;
            con = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            da = new SqlDataAdapter("Select *From HalToplam", con);
            ds = new DataSet();
            con.Open();
            da.Fill(ds, "Çeşit");
            da.Fill(ds, "Kg");
            dataGridView3.DataSource = ds.Tables["Çeşit"];
            dataGridView3.DataSource = ds.Tables["Kg"];
            con.Close();
            
            
        }
        #region seppette sil denemesi
        //private void button8_Click(object sender, EventArgs e)// Hal Sepeti silme
        //{
        //    if (textBox3.Text != "")
        //    {
        //        SqlConnection con;
        //        SqlCommand cmd;
        //        con = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");

        //        cmd = new SqlCommand();
        //        con.Open();
        //        cmd.Connection = con;
        //        cmd.CommandText = "delete from HalToplam where ID=" + textBox3.Text + "";
        //        cmd.CommandText = "delete from HalToplam where ID=" + textBox3.Text + "";
        //        cmd.ExecuteNonQuery();
        //        con.Close();
        //        toplam();
        //    }
        //    else { MessageBox.Show("Lütfen ID giriniz"); }
        //}
        #endregion
        private void button4_Click(object sender, EventArgs e)// ID ve Tablo row temizleme
        {
            
            SqlConnection baglanti2 = new SqlConnection("server=.; Initial Catalog=Hal;Integrated Security=SSPI");
            SqlCommand cmd2 = new SqlCommand("DELETE FROM HalToplam", baglanti2);
            SqlCommand cmd3 = new SqlCommand("TRUNCATE TABLE HalToplam", baglanti2); //silinen tablo id sıfırlamak için
            baglanti2.Open();
            cmd3.ExecuteNonQuery();
            cmd2.ExecuteNonQuery();            
            baglanti2.Close();
            toplam();



        }
    }
}
